package de.clausthal.tu.ielf.resusdesigner.model;

public class IndexPairs{
	public int id;
	public String tag;
	public String unit;
	public boolean forward;
	public double coefficient;
}
