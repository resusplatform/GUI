package de.clausthal.tu.ielf.resusdesigner.model;

import java.util.ArrayList;

public  class Realization{
	
	public String label;
	public String unit;
	public Realization()
	{
	
	}
	
	
}