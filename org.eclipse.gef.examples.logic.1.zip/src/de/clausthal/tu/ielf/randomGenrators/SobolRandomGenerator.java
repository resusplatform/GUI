package de.clausthal.tu.ielf.randomGenrators;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.dialogs.MessageDialog;
import org.osgi.framework.Bundle;

import de.clausthal.tu.ielf.resusdesigner.model.commands.CreateBendpointCommand;

public class SobolRandomGenerator extends  Random{
	
	private String Dir_file;
	private static Scanner scanner;
	// sobol.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
	//
	// Frances Y. Kuo
	//
	// Email: <f.kuo@unsw.edu.au>
	// School of Mathematics and Statistics
	// University of New South Wales
	// Sydney NSW 2052, Australia
	// 
	// Last updated: 21 October 2008
	//
	//   You may incorporate this source code into your own program 
	//   provided that you
	//   1) acknowledge the copyright owner in your program and publication
	//   2) notify the copyright owner by email
	//   3) offer feedback regarding your experience with different direction numbers
	//
	//
	// -----------------------------------------------------------------------------
	// Licence pertaining to sobol.cc and the accompanying sets of direction numbers
	// -----------------------------------------------------------------------------
	// Copyright (c) 2008, Frances Y. Kuo and Stephen Joe
	// All rights reserved.
	// 
	// Redistribution and use in source and binary forms, with or without
	// modification, are permitted provided that the following conditions are met:
	// 
//	     * Redistributions of source code must retain the above copyright
//	       notice, this list of conditions and the following disclaimer.
	// 
//	     * Redistributions in binary form must reproduce the above copyright
//	       notice, this list of conditions and the following disclaimer in the
//	       documentation and/or other materials provided with the distribution.
	// 
//	     * Neither the names of the copyright holders nor the names of the
//	       University of New South Wales and the University of Waikato
//	       and its contributors may be used to endorse or promote products derived
//	       from this software without specific prior written permission.
	// 
	// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
	// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
	// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
	// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY
	// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
	// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
	// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
	// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
	// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
	// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	// -----------------------------------------------------------------------------

	

	// ----- SOBOL POINTS GENERATOR BASED ON GRAYCODE ORDER -----------------
	// INPUT: 
	//   N         number of points  (cannot be greater than 2^32)
	//   D         dimension  (make sure that the data file contains enough data!!)      
	//   dir_file  the input file containing direction numbers
	//
	// OUTPUT:
	//   A 2-dimensional array POINTS, where
//	     
//	     POINTS[i][j] = the jth component of the ith point,
	//   
	//   with i indexed from 0 to N-1 and j indexed from 0 to D-1
	//
	// ----------------------------------------------------------------------

	
	public SobolRandomGenerator(int realizaions, int parameters) {
		super(realizaions, parameters);
		
		Dir_file="new-joe-kuo-7.21201";
		createLookupTable();
	}

	public static double [][]sobol_points( int  N, int D, String dir_file)
	{
		try 
		{	
			
			
			
			//TODO: change the text if the package nam in MANIFEST.INF is changed
			Bundle bundle = Platform.getBundle("de.clausthal.tu.ielf.resus");//"org.eclipse.gef.examples.logic");

			scanner = new Scanner(bundle.getEntry("resc/new-joe-kuo-7.21201").openStream());	

			if (!scanner.hasNext()) {
				System.err.println("Input file containing direction numbers cannot be found!\n");
				System.exit(1);
			}
			scanner.nextLine();	
	  
			System.out.println("the scanner is ok");
	  // L = max number of bits needed 
		  int L = (int)Math.ceil(Math.log((double)N)/Math.log(2.0)); 
	
		  // C[i] = index from the right of the first zero bit of i
		  int C[]  = new int [N];
		  C[0] = 1;
		  for (int i=1;i<=N-1;i++) {
		    C[i] = 1;
		    int value = i;
		    while ((value & 1)==1) {
		      value >>= 1;
		      C[i]++;
		    }
		  }
		  
		  // POINTS[i][j] = the jth component of the ith point
		  //                with i indexed from 0 to N-1 and j indexed from 0 to D-1
		  double [][]POINTS = new double [N][];
		  for (int i=0;i<=N-1;i++) POINTS[i] = new double [D];
		  for (int j=0;j<=D-1;j++) POINTS[0][j] = 0; 
	
		  // ----- Compute the first dimension -----
		  
		  // Compute direction numbers V[1] to V[L], scaled by pow(2,32)
		  int  V[] = new int [L+1]; 
		  for (int i=1;i<=L;i++) V[i] = 1 << (31-i); // all m's = 1
	
		  // Evalulate X[0] to X[N-1], scaled by pow(2,32)
		 int []X = new int [N];
		  X[0] = 0;
		  for (int i=1;i<=N-1;i++) {
		    X[i] = X[i-1] ^ V[C[i-1]];
		    POINTS[i][0] = (double)X[i]/Math.pow(2.0,31); // *** the actual points
		    //        ^ 0 for first dimension
		  }
		  
		  // Clean up
		 
		  
		  
		  // ----- Compute the remaining dimensions -----
		  for (int j=1;j<=D-1;j++) {
		    
		     // Read in parameters from file 
		    int d, s;
		    int a;
		    System.out.println(scanner.hasNext());
		    d=scanner.nextInt();
		    s=scanner.nextInt();
		    a=scanner.nextInt();
		   
		    //infile >> d >> s >> a;
		    int []m = new int [s+1];
		    for (int  i=1;i<=s;i++) m[i]=scanner.nextInt();
		    
		    // Compute direction numbers V[1] to V[L], scaled by pow(2,32)
		    V = new int [L+1];
		    if (L <= s) {
		      for (int i=1;i<=L;i++) V[i] = m[i] << (31-i); 
		    }
		    else {
		      for (int i=1;i<=s;i++) V[i] = m[i] << (31-i); 
		      for (int i=s+1;i<=L;i++) {
			V[i] = V[i-s] ^ (V[i-s] >> s); 
			for (int k=1;k<=s-1;k++) 
			  V[i] ^= (((a >> (s-1-k)) & 1) * V[i-k]); 
		      }
		    }
		    
		    // Evalulate X[0] to X[N-1], scaled by pow(2,32)
		    X = new int[N];
		    X[0] = 0;
		    for (int i=1;i<=N-1;i++) {
		      X[i] = X[i-1] ^ V[C[i-1]];
		      POINTS[i][j] = (double)X[i]/Math.pow(2.0,31); // *** the actual points
		      //        ^ j for dimension (j+1)
		   }
		   
		   
		  }
		  
		   
		  return POINTS;
	}catch(Exception y){
	    MessageDialog.openError(null,"error",y.getMessage());	
		System.out.println(y.getMessage());
	}
	return null;
	}

	@Override
	public void createLookupTable() {
		// TODO Auto-generated method stub
		super.createLookupTable();
		
		//new-joe-kuo-7.21201 (Das System kann die angegebene Datei nicht finden)
		table=sobol_points(realizations, parameters, this.Dir_file);
	}
//	public static void  main(String[] args)
//	{
////	  if (args.length != 4) {
////	    System.out.println();
////	    System.out.println("input format: sobol N D FILENAME");
////	    System.out.println();
////	    System.out.println("The program prints the first N sobol points in D dimensions.");
////	    System.out.println("The points are generated in graycode order." );
////	    System.out.println("The primitive polynomials and initial direction numbers are");
////		 System.out.println("given by the input file FILENAME.");
////	    return ;
////	  }
////
////	  int N = Integer.parseInt(args[1]);
////	  int D = Integer.parseInt(args[2]);
//	  int N=15;
//	  int D=3;
//		double [][]P = sobol_points(N,D,"C:\\Users\\jgh10\\Desktop\\new-joe-kuo-7.21201"); 
//
//	  // display points
//	  //cout << setprecision(20);
//	  //cout << setiosflags(ios::scientific) << setprecision(10);
//	  for (int i=0;i<=N-1;i++) {
//	    for (int j=0;j<=D-1;j++) System.out.print( P[i][j] + " ") ;
//	    System.out.println();
//	  }
//	  System.out.println();
//	}
	

}
